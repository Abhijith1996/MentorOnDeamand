IF EXISTS (SELECT * FROM sys.databases WHERE name = N'mentor_on_demand')
BEGIN
       DROP DATABASE mentor_on_demand
       CREATE DATABASE mentor_on_demand
END
ELSE
BEGIN
       CREATE DATABASE mentor_on_demand
END
GO

USE mentor_on_demand
GO

/****** Object:  Table :- course ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE course(
       [id] [int] IDENTITY(1,1) NOT NULL,
       [course_name] [varchar](20) NOT NULL,
       [fee] [bigint] NOT NULL,
	   [commission_amount] [bigint] NULL
CONSTRAINT [PK_course] PRIMARY KEY CLUSTERED 
(
       [id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

SET IDENTITY_INSERT course ON
INSERT INTO course (id,course_name,fee) VALUES
(1,'Java',2000),
(2,'C#',3000);
SET IDENTITY_INSERT course Off
drop table course
select * from course


/****** Object:  Table :- user ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[user](
       [id] [int] IDENTITY(1,1) NOT NULL,
       [first_name] [varchar](20) NOT NULL,
       [last_name] [varchar](20) NOT NULL,
       [age] [int] NOT NULL,
       [location][varchar](30)NOT NULL,
       [contact_number][bigint] NOT NULL,
       [user_name][varchar](20) NOT NULL,
       [password] [varchar](20) NOT NULL,
       [role][varchar](10) NOT NULL,
CONSTRAINT [PK_user] PRIMARY KEY CLUSTERED 
(
       [id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

SET IDENTITY_INSERT [dbo].[user] ON
INSERT INTO [dbo].[user] (id,first_name,last_name,age,location,contact_number,user_name,password,role) VALUES
(1,'Karthik','R',21,'Chennai',9532842567,'karthi@gmail.com','karthi123','admin'),
(2,'Roshni','Krishnan',22,'Chennai',9532842567,'roshni@gmail.com','rosh123','user'),
(3,'Abhjith','J',23,'Chennai',9532842567,'abhi@gmail.com','abhi123','user');
SET IDENTITY_INSERT [dbo].[user] Off

select * from [dbo].[user]



/****** Object:  Table :- mentor ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE mentor(
       [id] [int] IDENTITY(1,1) NOT NULL,
       [first_name] [varchar](20) NOT NULL,
       [last_name] [varchar](20) NOT NULL,
       [age] [int] NOT NULL,
       [location][varchar](30)NOT NULL,
       [linkedin_url][varchar](30)NOT NULL,
       [contact_number][bigint] NOT NULL,
       [year_of_experience][int] NOT NULL,
       [active][bit]NOT NULL,
       [course_name][varchar](20) NOT NULL,
       [user_name][varchar](20) NOT NULL,
       [password] [varchar](20) NOT NULL,
       [confirm_signup][bit] NULL,
       [reset_Password_date][date] NULL,
       [reset_password][bit] NULL
CONSTRAINT [PK_mentor] PRIMARY KEY CLUSTERED 
(
       [id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

SET IDENTITY_INSERT mentor ON
INSERT INTO mentor (id,first_name,last_name,age,location,linkedin_url,contact_number,year_of_experience,active,course_name,user_name,password) VALUES
(1,'Prakah','V',44,'Chennai','www.linkedin.com/in/prakash',9532842567,3,1,'C#','prakash@gmail.com','karthi123');
SET IDENTITY_INSERT mentor Off

select * from mentor
delete from mentor

/****** Object:  Table :- reservation ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE training(
       [id] [int] IDENTITY(1,1) NOT NULL,
       [user_id] [int] NOT NULL,
       [mentor_id] [int] NOT NULL,
       [course_name] [varchar](20) NOT NULL,
       [start_date][date]NULL,
       [end_date][date]NULL,
       [status][bit] NOT NULL,
       [progress][varchar](20) NULL,
       [amount_paid][bigint] NULL,
       [completion_percentage][int] NULL,
       [amount_to_mentor][float] NULL,
       [rating][float] NULL
CONSTRAINT [PK_training] PRIMARY KEY CLUSTERED 
(
       [id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
ALTER TABLE training  WITH CHECK ADD  CONSTRAINT [user_id_fk] FOREIGN KEY([user_id])
REFERENCES [dbo].[user] ([id])
GO
ALTER TABLE training CHECK CONSTRAINT [user_id_fk]
GO
ALTER TABLE training  WITH CHECK ADD  CONSTRAINT [mentor_id_fk] FOREIGN KEY([mentor_id])
REFERENCES mentor ([id])
GO
ALTER TABLE training CHECK CONSTRAINT [mentor_id_fk]
GO


SET IDENTITY_INSERT training ON
INSERT INTO training (id,user_id,mentor_id,course_name,start_date,end_date,status,progress,amount_paid,completion_percentage,amount_to_mentor,rating) VALUES
(1,2,11,'C#','2020/3/4','2020/3/12',0,'Requested',null,null,null,null),
(2,2,13,'Javascript','2020/2/12','2020/2/28',1,'Accepted',3000,0,1000,3.0),
(3,2,15,'HTML','2020/2/17','2020/3/4',1,'Completed',2000,100,1000,2.9),
(4,2,13,'Angular','2020/2/12','2020/2/28',1,'In-Progress',3000,25,1000,3.0),
(5,2,11,'Css','2020/3/4','2020/3/12',0,'Rejected',null,null,null,null);
SET IDENTITY_INSERT training Off
update training set progress='Accepted',completion_percentage=0 where id=2
select * from training
drop table training