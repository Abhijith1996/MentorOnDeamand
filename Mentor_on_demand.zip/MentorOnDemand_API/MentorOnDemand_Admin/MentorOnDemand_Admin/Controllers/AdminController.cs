﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using MentorOnDemand_Admin.Models;

namespace MentorOnDemand_Admin.Controllers
{
    [EnableCors("MentorOnDemandPolicy")]
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {

        mentor_on_demandContext mod = new mentor_on_demandContext();



        [HttpGet]
        [Route("GetAllMentor")]
        public IActionResult GetAllMentor()
        {
            return Ok(mod.Mentor);
        }


        [HttpPost("{mentorId}/{status}")]
        public IActionResult BlockMentor(int mentorId, string status)
        {
            Mentor mentor = mod.Mentor.Where(m => m.Id == mentorId).FirstOrDefault();
            if (status == "block")
            {
                mentor.Active = false;
                mod.SaveChanges();
                return Ok(new { status = "block", Detail=mentor });
            }
            else
            {
                mentor.Active = true;
                mod.SaveChanges();
                return Ok(new { status = "Unblock", Detail = mentor });
            }
        }
    }

}
