﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using MentorOnDemand_Request.Models;

namespace MentorOnDemand_Request.Controllers
{
    [EnableCors("MentorOnDemandPolicy")]
    [Route("api/[controller]")]
    [ApiController]
    public class RequestController : ControllerBase
    {
        mentor_on_demandContext mod = new mentor_on_demandContext();

        [Route("RequestForMentor/{mentorId}/{userId}")]
        [HttpPost]
        public IActionResult RequestForMentor(int mentorId, int userId)
        {
            Mentor mentor = mod.Mentor.Where(m => m.Id == mentorId).FirstOrDefault();
            Course course = mod.Course.Where(c => c.CourseName == mentor.CourseName).FirstOrDefault();
            Training training = new Training();
            training.MentorId = mentorId;
            training.UserId = userId;
            training.CourseName = mentor.CourseName;
            training.StartDate = DateTime.Now.Date;
            training.Status = false;
            training.AmountPaid = course.Fee + course.CommissionAmount;
            training.Progress = "Requested";
            mod.Training.Add(training);
            mod.SaveChanges();

            return Ok(new { status = "Requested" });
        }
    }
}
