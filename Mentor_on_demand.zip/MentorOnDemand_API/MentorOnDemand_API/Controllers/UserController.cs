﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MentorOnDemand_API.Models;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace MentorOnDemand_API.Controllers
{
    [EnableCors("MentorOnDemandPolicy")]
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        mentor_on_demandContext mod = new mentor_on_demandContext();

        [HttpPost("{role}")]
        public IActionResult LoginUser([FromBody] Credential credentials, string role)
        {
            var loggedUser = mod.User.Where(u => u.UserName == credentials.UserName && u.Password == credentials.Password && u.Role == role).FirstOrDefault();
            if (loggedUser != null)
            {
                return Ok(new { status = "Matched", user = loggedUser });
            }
            else
            {
                return Ok(new { status = "No Match" });
            }
        }

        [HttpPost]
        public IActionResult Post([FromBody] User user)
        {
            User newUser = new User();
            newUser.FirstName = user.FirstName;
            newUser.LastName = user.LastName;
            newUser.Age = user.Age;
            newUser.Location = user.Location;
            newUser.ContactNumber = user.ContactNumber;
            newUser.UserName = user.UserName;
            newUser.Password = user.Password;
            newUser.Role = "user";
            mod.User.Add(newUser);
            mod.SaveChanges();
            return Ok(new { status = "Registered" });
        }
        [HttpGet("{Id}")]
        public IActionResult getTrainingById(int Id)
        {

            var Training = from training in mod.Training.Where(t => t.Id == Id)
                           select new
                           {
                               training.Id,
                               training.Mentor.FirstName,
                               training.Mentor.LastName,
                               userFirstName = training.User.FirstName,
                               userLastName = training.User.LastName,
                               training.Progress,
                               training.CourseName,
                               training.AmountPaid,
                               training.StartDate,
                               training.EndDate,
                               training.Status,
                               training.CompletionPercentage,
                               training.AmountToMentor,
                               training.Rating
                           };
            return Ok(Training);
        }


        [HttpPut("{id}/{percentage}")]
        public IActionResult UpdateCompletionStatus(int id, int percentage)
        {
            Training myTraining = mod.Training.Where(t => t.Id == id).FirstOrDefault();
            myTraining.CompletionPercentage = percentage;
            myTraining.Progress = "In-Progress";
            if(percentage==25)
            {
                myTraining.AmountToMentor= myTraining.AmountPaid * 0.9 * 0.25;
            }

            if (percentage == 50)
            {
                myTraining.AmountToMentor = myTraining.AmountPaid * 0.9 * 0.5;
            }
            if (percentage == 75)
            {
                myTraining.AmountToMentor = myTraining.AmountPaid * 0.9 * 0.75;
            }
            mod.SaveChanges();
            return Ok(new { status = "Updated" , training = myTraining});
        }

        [HttpPost("{id}/{percentage}/{rate}")]
        public IActionResult CompletionStatus(int id, int percentage,int rate)
        {
            Training myTraining = mod.Training.Where(t => t.Id == id).FirstOrDefault();
            myTraining.CompletionPercentage = percentage;
            myTraining.Progress = "Completed";
            myTraining.Rating = rate;
            myTraining.AmountToMentor = myTraining.AmountPaid * 0.9;
            mod.SaveChanges();
            return Ok(new { status = "Updated", training = myTraining });
        }



    }

    }
