﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using MentorOnDemand_Training.Models;

namespace MentorOnDemand_Training.Controllers
{
    [EnableCors("MentorOnDemandPolicy")]
    [Route("api/[controller]")]
    [ApiController]
    public class TrainingController : ControllerBase
    {
        mentor_on_demandContext mod = new mentor_on_demandContext();


        [Route("GetMentorTraining/{id}")]
        [HttpGet("{id}")]
        public IActionResult GetMentorTraining(int id)
        {
            var Training = from training in mod.Training.Where(t => t.MentorId == id)
                           select new
                           {
                               training.Id,
                               training.Mentor.FirstName,
                               userFirstName = training.User.FirstName,
                               training.Progress,
                               training.CourseName,
                               training.AmountPaid,
                               training.StartDate,
                               training.EndDate,
                               training.CompletionPercentage,
                               training.Status,
                               training.AmountToMentor,
                               training.Rating
                           };
            return Ok(Training);
        }

        [Route("GetUserTraining/{id}")]
        [HttpGet("{id}")]
        public IActionResult GetUserTraining(int id)
        {
            var Training = from training in mod.Training.Where(t => t.UserId == id)
                           select new
                           {
                               training.Id,
                               training.Mentor.FirstName,
                               userFirstName = training.User.FirstName,
                               training.Progress,
                               training.CourseName,
                               training.AmountPaid,
                               training.StartDate,
                               training.EndDate,
                               training.Status,
                               training.CompletionPercentage,
                               training.AmountToMentor,
                               training.Rating
                           };
            return Ok(Training);
        }


        [HttpPut("{id}")]
        public IActionResult StartTraining(int id)
        {
            Training myTraining = mod.Training.Where(t => t.Id == id).FirstOrDefault();
            myTraining.StartDate = DateTime.Now.Date;
            myTraining.Progress = "In-Progress";
            myTraining.CompletionPercentage = 0;
            mod.SaveChanges();
            return Ok(new { status = "Training Started" });
        }


    }

}