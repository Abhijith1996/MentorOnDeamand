﻿using System;
using System.Collections.Generic;

namespace MentorOnDemand_Training.Models
{
    public partial class Training
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public int MentorId { get; set; }
        public string CourseName { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public bool Status { get; set; }
        public string Progress { get; set; }
        public long? AmountPaid { get; set; }
        public int? CompletionPercentage { get; set; }
        public double? AmountToMentor { get; set; }
        public double? Rating { get; set; }

        public virtual Mentor Mentor { get; set; }
        public virtual User User { get; set; }
    }
}
