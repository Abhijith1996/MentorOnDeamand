﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MentorOnDemand.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace MentorOnDemand.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MentorController : ControllerBase
    {
        mentor_on_demandContext mod = new mentor_on_demandContext();

        [HttpGet]
        [Route("MentorLogin")]
        public IActionResult MentorLogin(Mentor credentials)
        {
            var loggedUser = mod.Mentor.Where(u => u.UserName == credentials.UserName && u.Password == u.Password && u.Active == true).FirstOrDefault();
            if (loggedUser != null)
            {
                return Ok(new { status = "Matched", user = loggedUser });
            }
            else
            {
                return Ok(new { status = "No Match" });
            }
        }

        [HttpGet]
        [Route("GetAllMentor")]
        public IActionResult GetAllMentor()
        {
            return Ok(mod.Mentor);
        }

        [HttpPost]
        [Route("SignUp")]
        public IActionResult SignUp([FromBody]Mentor mentor)
        {
            Mentor newMentor = new Mentor();
            newMentor.FirstName = mentor.FirstName;
            newMentor.LastName = mentor.LastName;
            newMentor.Age = mentor.Age;
            newMentor.Location = mentor.Location;
            newMentor.LinkedinUrl = mentor.LinkedinUrl;
            newMentor.ContactNumber = mentor.ContactNumber;
            newMentor.YearOfExperience = mentor.YearOfExperience;
            newMentor.Active = mentor.Active;
            newMentor.CourseName = mentor.CourseName;
            newMentor.UserName = mentor.UserName;
            newMentor.Password = mentor.Password;
            mod.Mentor.Add(newMentor);
            mod.SaveChanges();
            return Ok(new { status = "Registered" });
        }

         
         
    }
}