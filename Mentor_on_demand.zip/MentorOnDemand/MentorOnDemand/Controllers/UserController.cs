﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MentorOnDemand.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace MentorOnDemand.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        mentor_on_demandContext mod = new mentor_on_demandContext();
       
        [HttpGet("{role}")]
        public IActionResult LoginUser(User credentials,string role)
        {
            var loggedUser = mod.User.Where(u => u.UserName == credentials.UserName && u.Password == u.Password && u.Role == role).FirstOrDefault();
            if(loggedUser!=null)
            {
                return Ok(new { status = "Matched", user = loggedUser });
            }
            else
            {
                return Ok(new { status = "No Match" });
            }
        }

        [HttpPost]
        public IActionResult SignUp([FromBody] User user)
        {
            User newUser = new User();
            newUser.FirstName = user.FirstName;
            newUser.LastName = user.LastName;
            newUser.Age = user.Age;
            newUser.Location = user.Location;
            newUser.ContactNumber = user.ContactNumber;
            newUser.UserName = user.UserName;
            newUser.Password = user.Password;
            newUser.Role = user.Role;
            mod.User.Add(newUser);
            mod.SaveChanges();
            return Ok(new { status = "Registered" });
        }
    }
}