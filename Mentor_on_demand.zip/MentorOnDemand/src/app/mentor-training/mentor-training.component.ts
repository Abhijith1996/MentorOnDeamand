import { Component, OnInit } from '@angular/core';
import { Training } from '../Model_Classes/Training';
import { MentorOnDemandService } from '../mentor-on-demand.service';
import { DatePipe } from '@angular/common';
// import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
@Component({
  selector: 'app-mentor-training',
  templateUrl: './mentor-training.component.html',
  styleUrls: ['./mentor-training.component.css']
})
export class MentorTrainingComponent implements OnInit {




  mytrainings:Training[]
  
  isAll: boolean
  today = new Date()
  isUndergoing: boolean
  isUpcoming: boolean
  isPrevious:boolean
  isRequest: boolean

  constructor(private mentorOnDemand:MentorOnDemandService,private datepipe: DatePipe) { }

  ngOnInit() {
    this.isAll = true
    this.mentorOnDemand.getMentorTraining().subscribe(
      data=>{
        console.log(data)
        this.mytrainings=data;
        this.mytrainings=this.mytrainings.sort()
      }
    )
  }
  
  onAll()
  {
    this.isAll = true
    this.isUndergoing = false
    this.isUpcoming = false
    this.isRequest = false
    this.isPrevious = false
  }
  onUndergoing()
  {
    this.isAll = false
    this.isUndergoing = true
    this.isUpcoming = false
    this.isRequest = false
    this.isPrevious = false
  }
  onUpcoming()
  {
    this.isAll = false
    this.isUndergoing = false
    this.isUpcoming =  true
    this.isRequest = false
    this.isPrevious = false
  }
  onPrevious()
  {
    this.isAll =  false
    this.isUndergoing = false
    this.isUpcoming = false
    this.isRequest = false
    this.isPrevious = true
  }
  onRequest()
  {
    this.isAll =  false
    this.isUndergoing = false
    this.isUpcoming = false
    this.isRequest = true
    this.isPrevious = false
  }
  undergoing()
  {
    return this.mytrainings.filter(mytraining => mytraining.progress=="In-Progress" && mytraining.status==true) 
  }
  upcoming()
  {
    return this.mytrainings.filter(mytraining => mytraining.progress=="Accepted")
  }
  request()
  {
    return this.mytrainings.filter(mytraining => mytraining.status==false && mytraining.progress=="Requested") 
  }
  previous()
  {
    return this.mytrainings.filter(mytraining =>  mytraining.progress=="Completed" &&  mytraining.status==true)
  }

  RequestRejectAccept(status:string, trainingId:number){

    console.log(status);
    console.log(trainingId)
    this.mentorOnDemand.RequestStatus(status,trainingId).subscribe(
      data=>{
        console.log(data)
    

  })
}



}
