import { Component, OnInit } from '@angular/core';
import { MentorOnDemandService } from '../mentor-on-demand.service';

@Component({
  selector: 'app-admin-home',
  templateUrl: './admin-home.component.html',
  styleUrls: ['./admin-home.component.css']
})
export class AdminHomeComponent implements OnInit {

  mentorList
  requested:boolean
  requestedMentor:number
  technology:any
    fullMentorList:any
    requestMentor:number
    constructor( private mentorOndemand:MentorOnDemandService) { }
  
    ngOnInit() {
   this.requested=false
      this.mentorOndemand.getAllActiveMentors().subscribe(
        data => {
          console.log(data)
          this.mentorList=data;
          this.technology=this.mentorList=data;
          this.fullMentorList=this.mentorList
      }
       ) 
    }
    onSearch(event:any)
    {
      if(event.target.value == '')
      {
        this.technology = this.fullMentorList
      }
      else
      {
        this.technology = this.technology.filter(course => course.courseName.toLocaleLowerCase().includes(event.target.value.toLocaleLowerCase()))
      }
    }




    onSendRequest(mentorId:number,status:string){
      this.requestMentor=mentorId
      this.requested=true;
      this.mentorOndemand.MentorBlockReq(this.requestMentor,status).subscribe(
        data => {
          console.log(data)
    })
  }
}