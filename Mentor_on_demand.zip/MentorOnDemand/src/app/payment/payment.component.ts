import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MentorOnDemandService } from '../mentor-on-demand.service';
import { Training } from '../Model_Classes/Training';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {

  constructor(private activateroute:ActivatedRoute,private mentorOnDemand:MentorOnDemandService,private router:Router) { }
trainingId:number;
newTraining:Training
  ngOnInit() {
    this.trainingId= this.activateroute.snapshot.params['curntUsrId'];
    console.log(this.trainingId)
    this.mentorOnDemand.getTrainingById(this.trainingId).subscribe(
      data=>{

        this.newTraining=data
        console.log(this.newTraining)
      })
  }

  onStartLearning(trainingId:number)
  {
    this.mentorOnDemand.StartLearning(trainingId).subscribe(
      data=>{
          console.log(data)
      })
      this.router.navigateByUrl('/viewTraining/'+trainingId)
  }
}
