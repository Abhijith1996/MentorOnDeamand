import { TestBed } from '@angular/core/testing';

import { MentorOnDemandService } from './mentor-on-demand.service';

describe('MentorOnDemandService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MentorOnDemandService = TestBed.get(MentorOnDemandService);
    expect(service).toBeTruthy();
  });
});
