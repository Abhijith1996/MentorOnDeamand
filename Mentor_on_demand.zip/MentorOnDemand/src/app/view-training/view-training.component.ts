import { Component, OnInit } from '@angular/core';
import { Training } from '../Model_Classes/Training';
import { ActivatedRoute, Router } from '@angular/router';
import { MentorOnDemandService } from '../mentor-on-demand.service';

@Component({
  selector: 'app-view-training',
  templateUrl: './view-training.component.html',
  styleUrls: ['./view-training.component.css']
})
export class ViewTrainingComponent implements OnInit {

firstQuarter:boolean=false;
secondQuarter:boolean=false
thirdQuarter:boolean=false
fourthQuarter:Boolean=false
Completed:boolean
rated:boolean=false;
  constructor(private activateroute:ActivatedRoute,private mentorOnDemand:MentorOnDemandService,private router:Router) { }

  trainingId:number;
  myTraining:Training
  status:Training
  rated1:boolean
  rated2:boolean
  rated3:boolean
  rated4:boolean
  rated5:boolean
  
  ngOnInit() {
    this.trainingId= this.activateroute.snapshot.params['trainingId'];
    console.log(this.trainingId)
    this.mentorOnDemand.getTrainingById(this.trainingId).subscribe(
      data=>{

        this.myTraining=data
        console.log(this.myTraining[0].completionPercentage)
        if(this.myTraining[0].completionPercentage == 0)
        {
          this.firstQuarter=true
        }
        if(this.myTraining[0].completionPercentage == 25)
        {
          this.secondQuarter=true 
        }
        if(this.myTraining[0].completionPercentage == 50)
        {
          this.thirdQuarter=true 
        }
        if(this.myTraining[0].completionPercentage == 75)
        {
          this.fourthQuarter=true 
        }
        console.log(this.myTraining)
      })
  }

  CompletionFirstQuater(){
    this.mentorOnDemand.UpdateCompletionStatus(this.trainingId,25).subscribe(
      data=>{
        console.log(data)
        this.status = data['training']
        if(this.status.completionPercentage==25)
        {
          this.firstQuarter=false
          this.secondQuarter=true
          this.thirdQuarter=false
          this.fourthQuarter=false
        }
      }
    )
  }

  CompletionSecondQuater(){
    this.mentorOnDemand.UpdateCompletionStatus(this.trainingId,50).subscribe(
      data=>{
        console.log(data)
        this.status = data['training']
        if(this.status.completionPercentage==50)
        {
          this.firstQuarter=false
          this.secondQuarter=false
          this.thirdQuarter=true
          this.fourthQuarter=false
        }
      }
    )
  }
  CompletionThirdQuater(){
    this.mentorOnDemand.UpdateCompletionStatus(this.trainingId,75).subscribe(
      data=>{
        console.log(data)
        this.status = data['training']
        if(this.status.completionPercentage==75)
        {
          this.firstQuarter=false
          this.secondQuarter=false
          this.thirdQuarter=false
          this.fourthQuarter=true
        }
      }
    )
  }
  CompletionLastQuater(){
    this.Completed = true;
  }
  UserRating(rate:number)
  {
    if(rate==1)
    {
    this.rated1=true;
    this.rated2=false;
    this.rated3=false;
    this.rated4=false;
    this.rated5=false;
    }
    else if(rate==2)
    {
    this.rated1=true;
    this.rated2=true;
    this.rated3=false;
    this.rated4=false;
    this.rated5=false;
    }
    else if(rate==3)
    {
    this.rated1=true;
    this.rated2=true;
    this.rated3=true;
    this.rated4=false;
    this.rated5=false;
  }
        else if(rate==4)
        {
          this.rated1=true;
          this.rated2=true;
          this.rated3=true;
          this.rated4=true;
          this.rated5=false;
  }
    else if(rate==5)
    {
      this.rated1=true;
      this.rated2=true;
      this.rated3=true;
      this.rated4=true;
      this.rated5=true;
    }

    this.mentorOnDemand.CompletionStatus(this.trainingId,100,rate).subscribe(
      data=>{
        console.log(data)
        this.status = data['training']
        if(this.status.completionPercentage==25)
        {
          this.firstQuarter=false
          this.secondQuarter=true
          this.thirdQuarter=false
          this.fourthQuarter=false
        }
      }
    )
  }

}
