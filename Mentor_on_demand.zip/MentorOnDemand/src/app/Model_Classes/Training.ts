export class Training
{
id?: number
firstName?: string
lastName?:string
userFirstName?: string
userLastName?:string
progress?: string
courseName?: string
amountPaid?: number
startDate?: Date
endDate?: Date
status?:boolean
completionPercentage?:number
amountToMentor?:number
rating?:number
} 