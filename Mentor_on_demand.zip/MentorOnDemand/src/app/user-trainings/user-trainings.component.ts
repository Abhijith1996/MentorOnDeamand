import { Component, OnInit } from '@angular/core';
import { MentorOnDemandService } from '../mentor-on-demand.service';
import { DatePipe } from '@angular/common';
import { Training } from '../Model_Classes/Training';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-trainings',
  templateUrl: './user-trainings.component.html',
  styleUrls: ['./user-trainings.component.css']
})
export class UserTrainingsComponent implements OnInit {


  isAll: boolean
  today = new Date()
  isUndergoing: boolean
  isUpcoming: boolean
  isPrevious:boolean
  isRequest: boolean



  mytrainings:Training[]
 

  constructor(private mentorOnDemand:MentorOnDemandService,private datepipe: DatePipe,private router:Router) { }

  ngOnInit() {
    this.isAll = true
    this.mentorOnDemand.getUserTraining().subscribe(
      data=>{
        console.log(data)
        this.mytrainings=data;
        this.mytrainings=this.mytrainings.sort()
      }
    )
  }
  onAll()
  {
    this.isAll = true
    this.isUndergoing = false
    this.isUpcoming = false
    this.isRequest = false
    this.isPrevious = false
  }
  onUndergoing()
  {
    this.isAll = false
    this.isUndergoing = true
    this.isUpcoming = false
    this.isRequest = false
    this.isPrevious = false
  }
  onUpcoming()
  {
    this.isAll = false
    this.isUndergoing = false
    this.isUpcoming =  true
    this.isRequest = false
    this.isPrevious = false
  }
  onPrevious()
  {
    this.isAll =  false
    this.isUndergoing = false
    this.isUpcoming = false
    this.isRequest = false
    this.isPrevious = true
  }
  onRequest()
  {
    this.isAll =  false
    this.isUndergoing = false
    this.isUpcoming = false
    this.isRequest = true
    this.isPrevious = false
  }

  upcoming()
  {
    return this.mytrainings.filter(mytraining =>   mytraining.progress=="Accepted")
  }

  undergoing()
  {
    return this.mytrainings.filter(mytraining => mytraining.progress=="In-Progress" && mytraining.status==true) 
  }
  
  request()
  {
    return this.mytrainings.filter(mytraining => mytraining.status==false && mytraining.progress=="Requested") 
  }
  previous()
  {
    return this.mytrainings.filter(mytraining =>  mytraining.progress=="Completed" &&  mytraining.status==true)
  }
  

  PaymentClick(curntUsrId:number){
console.log(curntUsrId)
    this.router.navigateByUrl('/payment/'+curntUsrId)



  }
  ShowCurrentTrainings(trainingId:number){
    this.router.navigateByUrl('/viewTraining/'+trainingId)
  }
}
