import { Injectable, ɵConsole } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { User } from './Model_Classes/User';
import { Training } from './Model_Classes/Training';
@Injectable({
  providedIn: 'root'
})
export class MentorOnDemandService {
loggedInUser:string;
signUpStatus: string;
currentLogged:User;
// currentLogged:string
  constructor(private http:HttpClient) { }


  authenticate(credentials:any)
  {
    
    let body = JSON.stringify(credentials.value)
    console.log(body);
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType':'text' })
    let options = { headers: header }
    return this.http.post("http://localhost:5000/api/user/"+this.loggedInUser,body,options)
  }

  mentorAuthenticate(credentials:any){
    let body = JSON.stringify(credentials.value)
    console.log(body);
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType':'text' })
    let options = { headers: header }
    return this.http.post("http://localhost:5010/api/mentor/MentorLogin",body,options)
  }
  signUpUser(user:any)
  {
    
    let body = JSON.stringify(user.value)
    console.log(body);
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType':'text' })
    let options = { headers: header }
    return this.http.post("http://localhost:5000/api/user",body,options)
  }

  signUpMentor(mentor:any)
  {
    
    let body = JSON.stringify(mentor.value)
    console.log(body);
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType':'text' })
    let options = { headers: header }
    return this.http.post("http://localhost:5010/api/mentor/signup",body,options)
  }
  

  
getAllMemtors(){
 
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType':'text' })
    let options = { headers: header }
    return this.http.get("http://localhost:5010/api/mentor/GetAllMentor")
}



getUserTraining()
{
  let data =this.currentLogged.id
  let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType': 'text' })
  let options = { headers: header };
  return this.http.get<Training[]>("http://localhost:5020/api/training/GetUserTraining/"+data,options)
}
getMentorTraining()
{
  let data =this.currentLogged.id
  console.log(data);
  let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType': 'text' })
  let options = { headers: header };
  return this.http.get<Training[]>("http://localhost:5020/api/training/GetMentorTraining/"+data,options)
}
getTrainingById(trainingId:number)
{
  let data =trainingId
  console.log(data);
  let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType': 'text' })
  let options = { headers: header };
  return this.http.get<Training>("http://localhost:5000/api/user/"+data,options)
}
StartLearning(trainingId:number)
{
  let data =trainingId
  console.log(data);
  let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType': 'text' })
  let options = { headers: header };
  console.log(this.http.put("http://localhost:44360/api/training/"+data,options))
  return this.http.put("http://localhost:44360/api/training/"+data,options)
}

UpdateCompletionStatus(id:number,percentage:number){
  let data =id+"/"+percentage;
  console.log(data);
  let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType': 'text' })
  let options = { headers: header };
  return this.http.put("http://localhost:5000/api/user/"+data,options)
}

CompletionStatus(id:number,percentage:number,rate:number)
{
  let data =id+"/"+percentage+"/"+rate;
  console.log(data);
  let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType': 'text' })
  let options = { headers: header };
  return this.http.post("http://localhost:5000/api/user/"+data,options)
}


RequestMentor(mentorId:number,userId:number)
{
  let data =mentorId+"/"+userId;
  console.log(data);
  let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType': 'text' })
  let options = { headers: header };
  return this.http.post("http://localhost:5030/api/request/RequestForMentor/"+data,options)
}


RequestStatus(status:string,Id:number)
{
  let data =Id+"/"+status;
  console.log(data);
  let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType': 'text' })
  let options = { headers: header };
  return this.http.post("http://localhost:5010/api/mentor/RequestStatus/"+data,options)
}

MentorBlockReq(id:number,status:string){
  let data =id+"/"+status;
  console.log(data);
  let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType': 'text' })
  let options = { headers: header };
  return this.http.post("http://localhost:5040/api/admin/"+data,options)

}

getAllActiveMentors(){

  let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType':'text' })
    let options = { headers: header }
    return this.http.get("http://localhost:5040/api/admin/GetAllMentor")
}
}