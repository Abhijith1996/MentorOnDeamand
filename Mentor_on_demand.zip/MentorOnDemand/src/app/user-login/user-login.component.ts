import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MentorOnDemandService } from '../mentor-on-demand.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit {
loginUser:string;
loginForm: FormGroup;
signupUser:string;
roleMentor:string='mentor'
roleUser:string='user'
mentorList
status:string;
isNotAuth:boolean
role
technology:any
  fullMentorList:any
data
loginStatus:boolean
  constructor(public formBuilder:FormBuilder, public mentorOndemand:MentorOnDemandService, public router:Router) { 

  }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      username: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(8)]]
  });   
  
      
  this.mentorOndemand.getAllMemtors().subscribe(
    data => {
      console.log(data)
      this.mentorList=data;
      this.technology=this.mentorList=data;
        this.fullMentorList=this.mentorList
  }
   ) 
  
  
  
  }

  adminClick(){
    
    this.mentorOndemand.loggedInUser="admin";
  
  this.loginUser=this.mentorOndemand.loggedInUser;
  console.log(this.loginUser)
 }

  mentorClick(){this.mentorOndemand.loggedInUser="mentor";
  this.loginUser=this.mentorOndemand.loggedInUser
 }

  userClick(){this.mentorOndemand.loggedInUser="user";
  this.loginUser=this.mentorOndemand.loggedInUser;
  }

  onAuthentication(){
    
  this.mentorOndemand.authenticate(this.loginForm).subscribe(    
    data => {
      console.log(data['status'])
      this.status=data['status'];
      console.log(data)
      
      
      if(this.status=="Matched" )
      {
        this.role=data['user']
        this.role = this.role.role 
        if(this.role=="user")
        {
          // this.mentorOndemand.currentLogged='user'
           this.mentorOndemand.currentLogged=data['user']
          this.router.navigateByUrl('/user')
        }
        if(this.role=="admin"){
        // {this.mentorOndemand.currentLogged='admin'
          this.mentorOndemand.currentLogged=data['user']
          this.router.navigateByUrl('/adminHome')
      }}
      if(this.status=="No Match" )
      {
        this.isNotAuth=true;
      }         

      })
   
    }


    onMentorAuthentication(){

      this.mentorOndemand.mentorAuthenticate(this.loginForm).subscribe(    
        data => {
          console.log(data['status'])
          this.status=data['status'];
          console.log(data)
          
          
          if(this.status=="Matched" )
          {
            this.mentorOndemand.currentLogged=data['user']
            
            // this.mentorOndemand.currentLogged="mentor"
              this.router.navigateByUrl('/mentorTrainings')
         
              
          }
          if(this.status=="No Match" )
          {
            this.isNotAuth=true;
          }         
    
          })
       

    }
  
  onMentorSignUp(){
    this.router.navigateByUrl('/signup/'+this.roleMentor)
    console.log("mentor Sign Up")

  }
onUserSignUp(){
  
  this.router.navigateByUrl('/signup/'+this.roleUser)

}


onDisplayMentor(){
  console.log("mentor listing")
this.mentorOndemand.getAllMemtors().subscribe(
  data => {
    console.log(data)
    this.mentorList=data;
}
 ) 



}
onSearch(event:any)
{
  console.log("dgfsdfsdfsdf")
  if(event.target.value == '')
  {
    this.technology = this.fullMentorList
  }
  else
  {
    this.technology = this.technology.filter(course => course.courseName.toLocaleLowerCase().includes(event.target.value.toLocaleLowerCase()))
  }
}
login(){
  this.loginStatus=true;
  this.loginUser="user";

}
}