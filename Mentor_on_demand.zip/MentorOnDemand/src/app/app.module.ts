import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { UserSignUpComponent } from './user-sign-up/user-sign-up.component';
import { ReactiveFormsModule } from '@angular/forms';
import { HeaderComponent } from './header/header/header.component';
import { HttpClientModule } from '@angular/common/http';
import { UserComponent } from './user/user.component';
import { UserTrainingsComponent } from './user-trainings/user-trainings.component';
import { DatePipe } from '@angular/common';
import { MentorTrainingComponent } from './mentor-training/mentor-training.component';
import { PaymentComponent } from './payment/payment.component';
import { ViewTrainingComponent } from './view-training/view-training.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { FooterComponent } from './footer/footer.component';

@NgModule({
  declarations: [
    AppComponent,
    UserLoginComponent,
    UserSignUpComponent,
    HeaderComponent,
    UserComponent,
    UserTrainingsComponent,
    MentorTrainingComponent,
    PaymentComponent,
    ViewTrainingComponent,
    AdminHomeComponent,
    FooterComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [DatePipe],
  bootstrap: [AppComponent]
})
export class AppModule { }
