import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { UserLoginComponent } from './user-login/user-login.component';
import { UserSignUpComponent } from './user-sign-up/user-sign-up.component';
import { UserComponent } from './user/user.component';
import { UserTrainingsComponent } from './user-trainings/user-trainings.component';
import { MentorTrainingComponent } from './mentor-training/mentor-training.component';
import { PaymentComponent } from './payment/payment.component';
import { ViewTrainingComponent } from './view-training/view-training.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';







const routes: Routes = [
  {path:'login', component:UserLoginComponent},
  {path:'signup/:role', component:UserSignUpComponent},
  {path:'user', component:UserComponent},
  
  {path:'userTrainings', component:UserTrainingsComponent},
  
  {path:'mentorTrainings', component:MentorTrainingComponent},
  {path:'payment/:curntUsrId', component:PaymentComponent},
  {path:'viewTraining/:trainingId', component:ViewTrainingComponent},
  {path:'adminHome', component:AdminHomeComponent},
  

  
{path:'',redirectTo:'login',pathMatch:'full'}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

