import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { MentorOnDemandService } from '../mentor-on-demand.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-user-sign-up',
  templateUrl: './user-sign-up.component.html',
  styleUrls: ['./user-sign-up.component.css']
})
export class UserSignUpComponent implements OnInit {
  userCreationForm:FormGroup;
  mentorCreationForm:FormGroup;
  signUpUser:string;
  role:string
  constructor(public formBuilder:FormBuilder, public mentorOnDeamd:MentorOnDemandService,public router:ActivatedRoute) { }

  ngOnInit() {
    this.role=this.router.snapshot.paramMap.get('role');
    console.log(this.role)
    this.userCreationForm = this.formBuilder.group({
     
      firstName:['',[Validators.required, Validators.maxLength(20)]],
      lastName:['',Validators.required],   
      contactNumber:['',[Validators.required, Validators.maxLength(10), Validators.pattern('[0-9]*$')]],
      location:['',[Validators.required, Validators.maxLength(20)]],
      password:['',[Validators.required,Validators.minLength(8)]],
      userName:['',[Validators.required, Validators.email]]
      
    })


    this.mentorCreationForm = this.formBuilder.group({
      
      firstName:['',[Validators.required, Validators.maxLength(20)]],
      lastName:['',Validators.required],
      age:['',Validators.required],
      courseName:['',Validators.required],
      linkedInUrl:['',Validators.required],
      yearOfExperience:['',Validators.required],   
      contactNumber:['',[Validators.required, Validators.maxLength(10), Validators.pattern('[0-9]*$')]],
      location:['',[Validators.required, Validators.maxLength(20)]],
      password:['',[Validators.required,Validators.minLength(8)]],
      userName:['',[Validators.required, Validators.email]]
      
    })
 
  }

  onUserSignUp(){
console.log("inside userSignUP")
 console.log(this.userCreationForm.value)
this.mentorOnDeamd.signUpUser(this.userCreationForm).subscribe(
  data => {
    console.log(data)
   
}
 )}

onMentorSubmit(){
  console.log("insiode mentoe signup")
  console.log(this.mentorCreationForm.value)
  this.mentorOnDeamd.signUpMentor(this.mentorCreationForm).subscribe(
    data => {
      console.log(data)
  
})
}
}



