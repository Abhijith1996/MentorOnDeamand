import { Component, OnInit } from '@angular/core';
import { MentorOnDemandService } from 'src/app/mentor-on-demand.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
loginUser:string;
  constructor( public mentorOndemand:MentorOnDemandService,public router:Router) { }

  ngOnInit() { }
  getCurrentUser(){
    // console.log(this.mentorOndemand.currentLogged)
     console.log(this.mentorOndemand.currentLogged.role)
    // this.loginUser=this.mentorOndemand.currentLogged['role'];
   // this.loginUser=this.mentorOndemand.currentLogged.role;
    return this.mentorOndemand.currentLogged;
  
  }
  onLogout(){
    this.loginUser=this.mentorOndemand.currentLogged=null;
    console.log("logout")
    this.router.navigateByUrl('/login');
  }
  onUserSignUp(){
  
    this.router.navigateByUrl('/signup/'+'user')
  
  }

  

}
